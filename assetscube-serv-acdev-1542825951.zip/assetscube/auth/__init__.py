from flask import Blueprint

bp_acauth = Blueprint('acauth', __name__)    # login reigsiter function routes