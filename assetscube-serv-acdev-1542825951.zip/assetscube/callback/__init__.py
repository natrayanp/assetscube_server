from flask import Blueprint

bp_accallbk = Blueprint('accallbk', __name__)    # oauth callback function routes